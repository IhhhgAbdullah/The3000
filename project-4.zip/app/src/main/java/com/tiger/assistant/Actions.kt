package com.tiger.assistant

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.view.KeyEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * ينفّذ الأوامر المحلية. يرجع نص الرد، أو null إذا لم يكن أمراً محلياً
 * (وعندها يُرسل الكلام للذكاء الاصطناعي).
 */
class Actions(private val ctx: Context) {

    private val http = OkHttpClient.Builder().callTimeout(40, TimeUnit.SECONDS).build()
    private val main = Handler(Looper.getMainLooper())
    private var sleepTask: Runnable? = null
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val needA11y = "فعّل خدمة إمكانية الوصول لمساعد تايغر من إعدادات التلفزيون أولاً"
    private val needRoot = "هذا الأمر يحتاج صلاحيات نظام أعلى ولا أستطيع تنفيذه حالياً"

    // ---------- أدوات ----------

    private fun norm(s: String): String = s.lowercase()
        .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')
        .replace(Regex("[\\p{Punct}،؟؛]"), " ")
        .replace(Regex("\\s+"), " ").trim()
        .replace(Regex("^(?:قم ب|قم |من فضلك |لو سمحت |يا تايغر |تايغر )+"), "")

    private fun start(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun openSettings(action: String, ok: String): String =
        if (start(Intent(action))) ok
        else if (start(Intent(Settings.ACTION_SETTINGS))) "فتحت الإعدادات العامة، لم أجد الصفحة المطلوبة"
        else "تعذر فتح الإعدادات"

    private fun mediaKey(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun a11y(): TigerAccessibilityService? = TigerAccessibilityService.instance

    private fun launchables() = ctx.packageManager.let { pm ->
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0) +
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    }

    private fun launchByLabel(fragment: String): String? {
        val pm = ctx.packageManager
        val f = fragment.lowercase()
        val app = launchables().firstOrNull { it.loadLabel(pm).toString().lowercase().contains(f) } ?: return null
        val pkg = app.activityInfo.packageName
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return null
        return if (start(i)) app.loadLabel(pm).toString() else null
    }

    private fun packageByLabel(fragment: String): String? {
        val pm = ctx.packageManager
        val f = fragment.lowercase()
        return launchables().firstOrNull { it.loadLabel(pm).toString().lowercase().contains(f) }
            ?.activityInfo?.packageName
    }

    private fun launchPackage(pkg: String): Boolean {
        val pm = ctx.packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return false
        return start(i)
    }

    private fun openStore() = launchPackage("com.android.vending")

    private fun storeSearch(q: String): Boolean =
        start(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(q)))) ||
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(q) + "&c=apps")))

    private fun webSearch(q: String): Boolean =
        start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)) ||
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))

    private fun youtubeSearch(q: String): Boolean {
        for (pkg in listOf("com.google.android.youtube.tv", "com.google.android.youtube")) {
            val i = Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra(SearchManager.QUERY, q)
            if (start(i)) return true
        }
        return start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
    }

    private fun openTvApp(): String {
        for (k in listOf("iptv", "wad", "forever", "smarters", "tivimate")) {
            val label = launchByLabel(k)
            if (label != null) return "فتحت $label، واختيار القناة داخله يكون بالريموت"
        }
        return "ما لقيت تطبيق قنوات مثبت. قل: افتح واد، أو افتح فوريفر"
    }

    private fun labelKey(n: String): String {
        val low = n.removePrefix("ال").trim().lowercase()
        return when {
            low.contains("wad") || low.startsWith("واد") -> "wad"
            low.contains("forever") || low.contains("فوريفر") || low.contains("فورايفر") -> "forever"
            low.contains("يوتيوب") || low.contains("يوتوب") -> "youtube"
            low.contains("نتفلكس") || low.contains("نتفليكس") -> "netflix"
            low.contains("شاهد") -> "shahid"
            low.contains("كروم") -> "chrome"
            low.contains("سبوتيفاي") -> "spotify"
            low.contains("ديزني") -> "disney"
            low.contains("f droid") || low.contains("fdroid") || low.contains("فدرويد") -> "f-droid"
            else -> low
        }
    }

    private fun localIp(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress
    } catch (e: Exception) { null }

    private suspend fun speedTest(): String = withContext(Dispatchers.IO) {
        try {
            val t0 = System.nanoTime()
            var total = 0L
            val req = Request.Builder().url("https://speed.cloudflare.com/__down?bytes=10000000").build()
            http.newCall(req).execute().use { r ->
                val stream = r.body!!.byteStream()
                val buf = ByteArray(65536)
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    total += n
                }
            }
            val sec = (System.nanoTime() - t0) / 1e9
            val mbps = total * 8 / 1e6 / sec
            "سرعة التنزيل تقريباً " + "%.1f".format(Locale.US, mbps) + " ميغابت في الثانية"
        } catch (e: Exception) { "تعذر فحص السرعة، تأكد من الاتصال بالإنترنت" }
    }

    private fun openApp(spoken: String): String {
        val low = spoken.trim().removePrefix("ال").trim().lowercase()
        fun ok(label: String) = "فتحت $label"

        if (low.startsWith("متصفح")) {
            return if (start(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)))
                "فتحت المتصفح" else "لا يوجد متصفح مثبت على الجهاز"
        }
        if (low.contains("متجر") || low.contains("بلاي ستور") || low.contains("play store")) {
            return if (openStore()) "فتحت المتجر" else "لم أجد متجر التطبيقات"
        }
        if (low.startsWith("اعدادات")) return openSettings(Settings.ACTION_SETTINGS, "فتحت الإعدادات")
        if (low.contains("iptv") || low.contains("اي بي تي في")) return openTvApp()
        if (low.contains("ملفات") || low.contains("file manager")) {
            val l = launchByLabel("file") ?: launchByLabel("ملفات")
            return if (l != null) ok(l) else "لم أجد مدير ملفات مثبتاً"
        }
        if (low.contains("صور") || low.contains("معرض") || low.contains("gallery")) {
            if (start(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))) return "فتحت معرض الصور"
            val l = launchByLabel("photos") ?: launchByLabel("gallery")
            return if (l != null) ok(l) else "لم أجد تطبيق صور"
        }
        if (low.contains("موسيقي") || low.contains("music")) {
            if (start(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))) return "فتحت تطبيق الموسيقى"
            val l = launchByLabel("music")
            return if (l != null) ok(l) else "لم أجد تطبيق موسيقى"
        }
        val l = launchByLabel(labelKey(spoken))
        return if (l != null) ok(l) else "ما لقيت تطبيق باسم $spoken"
    }

    // ---------- المعالج الرئيسي ----------

    suspend fun handle(raw: String): String? {
        val t = norm(raw)
        if (t.isEmpty()) return null
        fun has(vararg w: String) = w.any { t.contains(it) }
        fun all(vararg w: String) = w.all { t.contains(it) }

        // 0) أوامر لا يمكن تنفيذها بدون صلاحيات النظام
        if (has("ملء الشاشه", "ملئ الشاشه", "ترجم", "اقرا لي", "ما يظهر علي الشاشه",
                "الموجود علي الشاشه", "نفذ الخطوات", "رتب", "اغلق التطبيقات", "اوقف جميع",
                "اخر تطبيق", "اعد تشغيل الفيديو", "التطبيق التالي", "التطبيق السابق",
                "القناه التاليه", "القناه السابقه", "القناه رقم", "رقم القناه")) return needRoot

        // 1) مؤقت الإيقاف
        if (has("مؤقت") && has("ايقاف", "اطفاء", "اطفي")) {
            val min = Regex("(\\d+)").find(t)?.value?.toIntOrNull() ?: 30
            sleepTask?.let { main.removeCallbacks(it) }
            val task = Runnable {
                mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
                start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            }
            sleepTask = task
            main.postDelayed(task, min * 60_000L)
            return "ضبطت المؤقت $min دقيقة، وعند انتهائه أوقف الفيديو وأرجع للشاشة الرئيسية"
        }

        // 2) الصوت
        if (has("كتم")) {
            return if (has("الغ", "فك")) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                "ألغيت كتم الصوت"
            } else {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                "كتمت الصوت"
            }
        }
        if (all("ارفع", "صوت")) {
            repeat(2) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            return "رفعت الصوت"
        }
        if (has("اخفض", "خفض", "قلل") && has("صوت")) {
            repeat(2) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            return "خفضت الصوت"
        }

        // 3) التحكم بالفيديو
        if (has("فيديو")) {
            val r: String? = when {
                has("اوقف", "ايقاف", "وقف") -> { mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); "أوقفت الفيديو" }
                has("شغل", "تشغيل") -> { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); "شغلت الفيديو" }
                has("قدم", "تقديم") -> { mediaKey(KeyEvent.KEYCODE_MEDIA_FAST_FORWARD); "قدمت الفيديو" }
                has("ارجع", "رجع") -> { mediaKey(KeyEvent.KEYCODE_MEDIA_REWIND); "أرجعت الفيديو" }
                else -> null
            }
            if (r != null) return r
        }

        // 4) صفحات الإعدادات ومعلومات الجهاز
        if (has("واي فاي", "وايفاي", "wifi", "wi fi", "اتصل بالانترنت")) {
            val msg = if (has("اوقف", "اطفي", "شغل")) "فتحت إعدادات الواي فاي، أندرويد لا يسمح للتطبيقات بتشغيله أو إيقافه مباشرة"
            else "فتحت إعدادات الواي فاي"
            return openSettings(Settings.ACTION_WIFI_SETTINGS, msg)
        }
        if (has("بلوتوث", "بلوتث", "بلو توث"))
            return openSettings(Settings.ACTION_BLUETOOTH_SETTINGS, "فتحت إعدادات البلوتوث")
        if (has("دقه العرض", "4k", "فور كي", "حجم الشاشه", "اعدادات الشاشه"))
            return openSettings(Settings.ACTION_DISPLAY_SETTINGS, "فتحت إعدادات العرض، لا أستطيع تغيير الدقة تلقائياً")
        if (all("اعدادات", "صوت"))
            return openSettings(Settings.ACTION_SOUND_SETTINGS, "فتحت إعدادات الصوت")
        if (has("معلومات الجهاز"))
            return openSettings(Settings.ACTION_DEVICE_INFO_SETTINGS, "فتحت معلومات الجهاز")
        if (has("المطور"))
            return openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, "فتحت إعدادات المطور")
        if (all("تحديث", "النظام"))
            return openSettings("android.settings.SYSTEM_UPDATE_SETTINGS", "فتحت صفحة تحديث النظام")
        if (has("التطبيقات المثبته"))
            return openSettings(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS, "فتحت التطبيقات المثبتة")
        if (has("مساحه التخزين")) {
            val st = StatFs(Environment.getDataDirectory().path)
            val free = "%.1f".format(Locale.US, st.availableBytes / 1e9)
            val total = "%.1f".format(Locale.US, st.totalBytes / 1e9)
            openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "")
            return "المساحة الحرة $free جيجابايت من $total"
        }
        if (has("ذاكره التخزين المؤقت"))
            return openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "فتحت التخزين، امسح الكاش لكل تطبيق من هناك")
        if (has("اعدادات الجهاز") || t == "اعدادات" || t == "افتح اعدادات")
            return openSettings(Settings.ACTION_SETTINGS, "فتحت الإعدادات")

        // 5) الشبكة
        if (has("عنوان ip", "عنوان اي بي", "عنوان الاي بي", "عنوان الشبكه")) {
            val ip = localIp()
            return if (ip != null) "عنوان الجهاز في الشبكة $ip" else "لم أستطع معرفة العنوان"
        }
        if (has("سرعه الانترنت", "سرعه النت")) return speedTest()

        // 6) الطاقة
        if (has("تشغيل الجهاز", "اطفي الجهاز", "اطفاء الجهاز", "اغلق الجهاز")) {
            val s = a11y() ?: return needA11y
            return if (s.global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG))
                "فتحت قائمة الطاقة، اختر منها الإطفاء أو إعادة التشغيل"
            else needRoot
        }

        // 7) التنقل
        if (has("الشاشه الرئيسيه", "القائمه الرئيسيه", "قائمه التطبيقات")) {
            start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            return "رجعت للشاشة الرئيسية"
        }
        if (has("ارجع") && has("سابق", "صفحه")) {
            val s = a11y() ?: return needA11y
            s.global(AccessibilityService.GLOBAL_ACTION_BACK); return "رجعت للخلف"
        }
        if (has("الاشعارات", "الاشعار")) {
            val s = a11y() ?: return needA11y
            s.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); return "فتحت الإشعارات"
        }
        if (has("تعمل بالخلفيه", "التطبيقات الاخيره")) {
            val s = a11y() ?: return needA11y
            s.global(AccessibilityService.GLOBAL_ACTION_RECENTS); return "فتحت التطبيقات الأخيرة"
        }
        if (has("الاعلي") && has("انتقل", "اصعد", "مرر")) {
            val s = a11y() ?: return needA11y
            return if (s.scroll(false)) "انتقلت للأعلى" else "ما لقيت شيئاً قابلاً للتمرير"
        }
        if (has("الاسفل") && has("انتقل", "انزل", "مرر")) {
            val s = a11y() ?: return needA11y
            return if (s.scroll(true)) "انتقلت للأسفل" else "ما لقيت شيئاً قابلاً للتمرير"
        }
        if (has("اختر هذا العنصر", "اختر العنصر")) {
            val s = a11y() ?: return needA11y
            return if (s.clickFocused()) "اخترت العنصر" else "ما لقيت عنصراً محدداً"
        }

        // 8) القنوات
        if (has("افتح", "فتح", "اعرض", "حدث", "تحديث") && has("قنوات", "قناه")) return openTvApp()

        // 9) إدارة التطبيقات
        if (has("تطبيقات") && has("حدث", "تحديث")) {
            return if (openStore()) "فتحت المتجر، افتح قسم إدارة التطبيقات ثم التحديثات" else "لم أجد المتجر"
        }
        if (has("نزل", "حمل") && has("تطبيق")) {
            val q = t.substringAfterLast("تطبيق").trim().removePrefix("ا").trim()
                .replace(Regex("مجاني\\S*"), "").trim()
            return if (q.isEmpty()) { if (openStore()) "فتحت المتجر" else "لم أجد المتجر" }
            else { if (storeSearch(q)) "بحثت في المتجر عن $q" else "تعذر فتح المتجر" }
        }
        if (has("احذف", "حذف", "الغ تثبيت") && has("تطبيق")) {
            val name = t.substringAfterLast("تطبيق").trim().removePrefix("ا").trim()
            if (name.isEmpty() || name.startsWith("هذا")) return "قل اسم التطبيق الذي تريد حذفه، مثل: احذف تطبيق نتفلكس"
            val pkg = packageByLabel(labelKey(name)) ?: return "ما لقيت تطبيق باسم $name"
            return if (start(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))))
                "ظهرت شاشة تأكيد الحذف، وافق عليها بالريموت" else "تعذر بدء الحذف"
        }
        if (has("f droid", "fdroid")) {
            val l = launchByLabel("f-droid")
            return if (l != null) "فتحت $l" else "متجر F-Droid غير مثبت"
        }

        // 10) البحث
        if (has("ابحث", "دور علي")) {
            if (has("ابحث لي")) return null  // سؤال للذكاء الاصطناعي
            val parts = t.split("ابحث عن ")
            val q = (if (parts.size > 1) parts.last() else t.substringAfter("عن ", "")).trim()
            if (q.isEmpty()) return "عن ماذا تريد أن أبحث؟"
            if (has("يوتيوب", "يوتوب", "youtube")) {
                return if (youtubeSearch(q)) "أبحث في يوتيوب عن $q" else "تعذر فتح يوتيوب"
            }
            if (has("تطبيق", "تطبيقات")) {
                return if (storeSearch(q)) "بحثت في المتجر عن $q" else "تعذر فتح المتجر"
            }
            return if (webSearch(q)) "أبحث عن $q" else "لا يوجد متصفح لإتمام البحث"
        }

        // 11) فتح التطبيقات
        val m = Regex("^(?:افتح|فتح|شغل|تشغيل|روح علي|روح الي|ادخل علي|ادخل الي)\\s+(?:تطبيق\\s+|مشغل\\s+)?(.+)$").find(t)
        if (m != null) return openApp(m.groupValues[1])

        return null
    }
}
