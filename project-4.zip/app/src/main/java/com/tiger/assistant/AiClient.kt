package com.tiger.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * الذكاء الاصطناعي هو "الدماغ": يحوّل أي طلب إلى قائمة أوامر جاهزة
 * ينفذها التطبيق (Actions)، مع رد قصير يُقرأ صوتياً.
 */
class AiClient(private val endpoint: String) {

    data class Plan(val commands: List<String>, val reply: String)

    private val http = OkHttpClient.Builder()
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private val system = """
أنت دماغ مساعد صوتي عربي يتحكم بتلفزيون أندرويد. افهم طلب المستخدم (قد يكون بلهجة عراقية أو عامية) وحوّله إلى أوامر جاهزة من القائمة فقط.
أجب بـ JSON فقط، بدون أي نص قبله أو بعده وبدون علامات اقتباس ثلاثية، بهذا الشكل بالضبط:
{"commands":["أمر1","أمر2"],"reply":"ردّ قصير بالعربية"}

القواعد:
1) commands تحتوي فقط على صيغ من القائمة أدناه، بنفس الكلمات تقريباً. اتركها [] إذا كان الطلب سؤالاً أو حديثاً عادياً، وأجب عنه في reply بجملة أو جملتين بدون رموز أو تنسيق.
2) رتّب الأوامر: أوامر الصوت والفيديو والتنقل أولاً، وأي أمر يفتح تطبيقاً أو صفحة إعدادات أو بحثاً يكون آخر أمر وواحداً فقط.
3) لا تخترع أوامر خارج القائمة. إن كان الطلب غير ممكن فاشرح ذلك في reply وبدون أوامر.
4) لا تخمّن قيماً مثل عنوان IP أو السرعة أو المساحة، فالتطبيق يضيفها بنفسه.

الأوامر المتاحة:
- افتح <اسم تطبيق>  (يوتيوب، نتفلكس، المتصفح، متجر التطبيقات، الإعدادات، مدير الملفات، معرض الصور، الموسيقى، IPTV، واد، فوريفر، F-Droid)
- ابحث في اليوتيوب عن <نص>
- ابحث عن <نص>
- ابحث عن تطبيق <اسم>
- ارفع الصوت | اخفض الصوت | اكتم الصوت | الغ كتم الصوت
- شغل الفيديو | اوقف الفيديو | قدم الفيديو | ارجع الفيديو
- ارجع الى الصفحة السابقة | ارجع الى الشاشة الرئيسية | افتح الاشعارات | افتح التطبيقات الاخيرة | انتقل الى الاعلى | انتقل الى الاسفل | اختر هذا العنصر
- افتح اعدادات الواي فاي | افتح اعدادات البلوتوث | افتح اعدادات الشاشة | افتح اعدادات الصوت | افتح اعدادات المطور | اعرض معلومات الجهاز | افتح التطبيقات المثبتة
- افحص مساحة التخزين | اعرض عنوان IP | افحص سرعة الانترنت | افحص تحديثات النظام
- اضبط مؤقت ايقاف التشغيل <رقم> دقيقة
- نزل تطبيق <اسم> | احذف تطبيق <اسم>
- اطفاء الجهاز  (يفتح قائمة الطاقة)
""".trimIndent()

    suspend fun plan(userText: String): Plan = withContext(Dispatchers.IO) {
        val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", userText))
        val body = JSONObject()
            .put("max_tokens", 400)
            .put("system", system)
            .put("messages", msgs)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val req = Request.Builder().url(endpoint).post(body).build()
        http.newCall(req).execute().use { resp ->
            val raw = resp.body?.string() ?: ""
            if (!resp.isSuccessful) error("خطأ من الخادم ${resp.code}: " + raw.take(200))
            val text = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
            parse(text)
        }
    }

    private fun parse(text: String): Plan {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) return Plan(emptyList(), text.trim())
        return try {
            val o = JSONObject(text.substring(s, e + 1))
            val arr = o.optJSONArray("commands")
            val cmds = ArrayList<String>()
            if (arr != null) for (i in 0 until arr.length()) cmds.add(arr.optString(i))
            Plan(cmds.filter { it.isNotBlank() }, o.optString("reply", ""))
        } catch (ex: Exception) {
            Plan(emptyList(), text.trim())
        }
    }
}
