package com.tiger.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val NavyBg = Color(0xFF0B1B3A)
private val Gold = Color(0xFFD4AF37)

class MainActivity : ComponentActivity() {

    private lateinit var voice: VoiceController
    private lateinit var actions: Actions
    private val ai by lazy { AiClient(BuildConfig.AI_ENDPOINT) }

    private var status by mutableStateOf("اضغط الزر وقل أي طلب")
    private var reply by mutableStateOf("")

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) voice.startListening() else status = "نحتاج صلاحية الميكروفون"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actions = Actions(this)
        voice = VoiceController(
            ctx = this,
            onListening = { status = "أستمع إليك..." },
            onResult = { handle(it) },
            onFail = { status = it }
        )

        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier.fillMaxSize().background(NavyBg).padding(48.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("مساعد تايغر", color = Gold, fontSize = 40.sp)
                    Spacer(Modifier.height(32.dp))
                    Button(
                        onClick = ::onMicClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = NavyBg)
                    ) { Text("🎤  تكلم", fontSize = 28.sp, modifier = Modifier.padding(12.dp)) }
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = ::openAccessibility,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A6E), contentColor = Gold)
                    ) { Text("⚙  تفعيل التحكم الكامل", fontSize = 20.sp, modifier = Modifier.padding(8.dp)) }
                    Spacer(Modifier.height(24.dp))
                    Text(status, color = Color.White, fontSize = 22.sp)
                    Spacer(Modifier.height(16.dp))
                    Text(reply, color = Gold, fontSize = 26.sp)
                }
            }
        }
    }

    private fun openAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            status = "قائمة إمكانية الوصول غير متوفرة على هذا الجهاز"
        }
    }

    private fun onMicClick() {
        val ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) voice.startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun isNotable(r: String) =
        r.contains("عنوان") || r.contains("سرعة") || r.contains("المساحة") ||
            r.startsWith("ما لقيت") || r.startsWith("تعذر") || r.startsWith("فعّل") ||
            r.startsWith("هذا الأمر") || r.startsWith("لم أ") || r.startsWith("لا يوجد") ||
            r.startsWith("قل")

    private fun handle(text: String) {
        status = "سمعتك: $text"
        lifecycleScope.launch {
            reply = "..."
            var aiError: String? = null
            val plan = try {
                ai.plan(text)
            } catch (e: Exception) {
                aiError = e.message
                null
            }

            if (plan == null) {
                // الذكاء الاصطناعي غير متاح: نجرب الفهم المحلي
                val local = try { actions.handle(text) } catch (e: Exception) { null }
                reply = local ?: "تعذّر الاتصال بالذكاء الاصطناعي: $aiError"
                voice.speak(reply)
                return@launch
            }

            val extra = mutableListOf<String>()
            for ((i, c) in plan.commands.withIndex()) {
                if (i > 0) delay(1500)
                val r = try { actions.handle(c) } catch (e: Exception) { "تعذر تنفيذ الأمر: ${e.message}" }
                if (r == null) extra.add("لم أفهم: $c") else if (isNotable(r)) extra.add(r)
            }
            reply = (plan.reply + " " + extra.joinToString(". ")).trim()
            if (reply.isEmpty()) reply = "تم"
            voice.speak(reply)
        }
    }

    override fun onDestroy() {
        voice.release()
        super.onDestroy()
    }
}
